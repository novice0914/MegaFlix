document.addEventListener("DOMContentLoaded", () => {
    // 동적으로 데이터 로드하는 예시
    console.log("페이지 로드 완료");
});
